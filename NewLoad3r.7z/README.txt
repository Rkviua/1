　∧＿∧
（｡･ω･｡)つ━☆・*。
⊂　　 ノ 　　　・゜+.
　しーＪ　　　°。+ *´¨)
　　　　　　　　　.• ´¸.•*´¨) ¸.•*¨)                      
　　　　　　　　　　(¸.•´ (¸.•’*
________________________________________________

PASSWORD: 2024
Downloaded from github.com. Release confirmed by site moderation.
All rights and licence belong to the creator of the reader only. Modification of the code may result in liability.
To contact the creator - unkcreatorhax@gmail.com.
_________________________________________________

   (¯`v´¯))　　　　　　　　　　　　　 ((¯`v´¯)
　 `·.¸.·´ 　　　　　　　　　　　　　　`·.¸.·´
　 ¸.·´ ¸·´¨)　¸.·*¨)　　　　¸.·´¨)　¸.·*¨)　¸.·　
　(¸.·´　 (¸.·´　 (¸.•*¨`*•.　´　 (¸.·´　 (¸.•*
　　　　　　　　　／l
　　　　　　　　（ﾟ. ｡ 7
　　　　　　　　　l、 ~ヽ　.•　　
　　　　　　　　　じしf_, )ノ